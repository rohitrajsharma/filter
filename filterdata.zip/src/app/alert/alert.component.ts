import { Component, OnInit } from '@angular/core';

import {ValidationService } from '../ValidationService.service';

import { Alert, AlertType } from './alerts';


@Component({
  selector: 'app-alert',
  templateUrl: './alert.component.html',
  styleUrls: ['./alert.component.css']
})
export class AlertComponent implements OnInit {
  alerts: Alert[] = [];
  constructor(private validationService: ValidationService) { }

  ngOnInit() {
  this.validationService.getAlert().subscribe((alert: Alert) => {
            if (!alert) {
                // clear alerts when an empty alert is received
                this.alerts = [];
                return;
            }
            console.log(alert);
            this.alerts = [];
 			this.alerts.push(alert);
            // add alert to array
        });
  }

  cssClass(alert: Alert) {
        if (!alert) {
            return;
        }
 
        // return css class based on alert type
        switch (alert.type) {
            case AlertType.Success:
                return 'alertshow alert-success';
            case AlertType.Error:
                return 'alertshow alert-danger';
            case AlertType.Info:
                return 'alertshow alert-info';
            case AlertType.Warning:
                return 'alertshow alert-warning';
        }
    }

}

