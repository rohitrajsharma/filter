import { Component, OnInit } from '@angular/core';
import {Http,Response, Headers, RequestOptions} from '@angular/http';

import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';

import 'rxjs/add/operator/share';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';



@Component({
  selector: 'app-filter-data',
  templateUrl: './filter-data.component.html',
  styleUrls: ['./filter-data.component.css']
})
export class FilterDataComponent implements OnInit {
  
  dataFilters: object = {
  };

  dataFilterJson: any;
  filteredData: any;
  constructor(private http:Http) {
  		this.http.get("http://www.mocky.io/v2/59f74e342f0000ef145585de").map((res:any) => res.json())
                         .subscribe(data => {
                         	this.dataFilterJson = data;
                         	for(let i of this.dataFilterJson.categories){
                         		console.log(i);
                         		for(let g of i.items){
									let filtername = g.name.replace(/\s/g,'');
									g.filterName = filtername;		
                         			this.dataFilters[filtername] =false;
                         		}
                         	}
                         	console.log(this.dataFilters);
                         	//this.filteredData = this.generateArray(this.dataFilterJson.filters);
                         	//this._renderDetails(this.dataFilters);
  		}, error => console.log(error));
   }
 		


    onFilterChange(filter){
    	console.log(filter);
		this.dataFilters[filter]=!this.dataFilters[filter];
		console.log(this.dataFilterJson);
    	console.log(this.dataFilters);
		this._renderDetails(this.dataFilters);
	}

   _renderDetails(filter): void {
   		let companyData = this.dataFilterJson.categories;
   		this.filteredData = [];
                         	for(let i of companyData){
                         		console.log(i);
                         		for(let g of i.items){
                         			console.log(filter[g.filterName])			
                         			if(filter[g.filterName]){

										this.filteredData.push(g.info);
                         		}
                         	}
                         }
  console.log(this.filteredData);
  

			 
   }

  ngOnInit() {
  }



}
