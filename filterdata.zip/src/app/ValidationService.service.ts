import { Injectable} from '@angular/core';
import {Http,Response, Headers, RequestOptions} from '@angular/http';


import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';

import { Alert, AlertType } from './alert/alerts';


import 'rxjs/add/operator/share';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';
import 'rxjs/Rx';

@Injectable()

export class ValidationService {
	private subject = new Subject<Alert>();

  constructor(private http:Http) {}

	 public getJSON(): Observable<any> {
         return this.http.get("http://localhost:4200/assets/validation.json")
                         .map((res:any) => res.json())
     }

  getAlert(): Observable<any> {
        return this.subject.asObservable();
  }

  validateNumber(mobilenumber: number) {
  var obj;
  this.getJSON().subscribe(data => {obj=data;
  			console.log(obj);
  				this.alert(obj.errorCode, obj.errorMessage);		
  			}, error => console.log(error));
  	
  }
  

  alert(type: AlertType, message: string) {
        this.subject.next(<Alert>{ type: type, message: message });
    }
  
}